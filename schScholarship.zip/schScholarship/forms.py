from django import forms
from schSetup.setupModels.setup_cast_models import CastCategory
from schScholarship.models import AddScholarship
from seedData.models import Year


ADM_FACULTY = (
    ('', 'Choose...'),
    ('SCIENCE', 'SCIENCE'),
    ('COMMERCE', 'COMMERCE'),
    ('ARTS', 'ARTS'),
    ('VOCATIONAL', 'VOCATIONAL')
)

GENDER = (
    ('Girls',"Girls"),
    ('Boys',"Boys"),
)
APPLYFOR =(
    ('bpl',"BPL"),
    ('minority',"Minority"),
    ('pwd',"PWD"),
)

CAT=(
    ('OPEN',"OPEN"),
    ('OBC',"OBC"),
    ('SBC',"SBC"),
    ('SC',"SC"),
    ('ST',"ST"),
    ('NT C',"NT C"),
    ('NT B',"NT B"),
    ('NT D',"NT D"),
    ('VJ',"VJ"),
    ('VJNT',"VJNT"),
)



class AddScholarshipForm(forms.ModelForm):
    s_name = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Scholarship Name",'placeholder': "Enter Scholarship Name"}),label="Scholarship Name",max_length=50,min_length=2,required=True)   
    gender = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple,choices=GENDER,required=True)
    apply_for = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple,choices=APPLYFOR,required=False)
    category = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple,choices=CAT,required=False)
    class Meta:
        model = AddScholarship
        fields =('s_name','apply_for','gender','category',)


class PriScholarshipForm(forms.Form):
    s_name = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Scholarship Name"}),label="Scholarship Name",queryset=AddScholarship.objects.all(),required=True)
    year = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Year"}),label="Year",queryset=Year.objects.all(),required=True)
    class_from = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select From Class"}),label="From Class",choices=(('',"Choose..."),('1',"1"),('2',"2"),('3',"3"),('4',"4"),),required=True) 
    class_to = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select To Class"}),label="To Class",choices=(('',"Choose..."),('1',"1"),('2',"2"),('3',"3"),('4',"4"),),required=True)
    amount = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Amount Per Month",'type':"number",'placeholder': "Enter Amount Per Month",'onchange':"totalcal()"}),label="Amount Per Month",max_length=5,min_length=2,required=True)
    no_of_month = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Number of Month",'type':"number",'placeholder': "Enter Number of Month",'onchange':"totalcal()"}),label="Number of Month",max_length=2,min_length=1,required=True)
    total = forms.CharField(widget=forms.TextInput(attrs={'title': "Total",'type':"number",'placeholder': "Total",'readonly':"true"}),label="Total",max_length=10,min_length=1,required=True)
 


class SecScholarshipForm(forms.Form):
    s_name = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Scholarship Name"}),label="Scholarship Name",queryset=AddScholarship.objects.all(),required=True)
    year = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Year"}),label="Year",queryset=Year.objects.all(),required=True)
    class_from = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select From Class"}),label="From Class",choices=(('',"Choose..."),('5',"5"),('6',"6"),('7',"7"),('8',"8"),('9',"9"),('10',"10"),),required=True) 
    class_to = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select To Class"}),label="To Class",choices=(('',"Choose..."),('5',"5"),('6',"6"),('7',"7"),('8',"8"),('9',"9"),('10',"10"),),required=True)
    amount = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Amount Per Month",'type':"number",'placeholder': "Enter Amount Per Month",'onchange':"totalcal()"}),label="Amount Per Month",max_length=5,min_length=2,required=True)
    no_of_month = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Number of Month",'type':"number",'placeholder': "Enter Number of Month",'onchange':"totalcal()"}),label="Number of Month",max_length=2,min_length=1,required=True)
    total = forms.CharField(widget=forms.TextInput(attrs={'title': "Total",'type':"number",'placeholder': "Total",'readonly':"true"}),label="Total",max_length=10,min_length=1,required=True)



class ColScholarshipForm(forms.Form):
    s_name = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Scholarship Name"}),label="Scholarship Name",queryset=AddScholarship.objects.all(),required=True)
    year = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Year"}),label="Year",queryset=Year.objects.all(),required=True)
    class_from = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select From Class"}),label="From Class",choices=(('',"Choose..."),('11',"11"),('12',"12"),),required=True) 
    class_to = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select To Class"}),label="To Class",choices=(('',"Choose..."),('11',"11"),('12',"12"),),required=True)
    faculty = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select Faculty"}),label="Faculty",choices=ADM_FACULTY,required=True)
    amount = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Amount Per Month",'type':"number",'placeholder': "Enter Amount Per Month",'onchange':"totalcal()"}),label="Amount Per Month",max_length=5,min_length=2,required=True)
    no_of_month = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Number of Month",'type':"number",'placeholder': "Enter Number of Month",'onchange':"totalcal()"}),label="Number of Month",max_length=2,min_length=1,required=True)
    total = forms.CharField(widget=forms.TextInput(attrs={'title': "Total",'type':"number",'placeholder': "Total",'readonly':"true"}),label="Total",max_length=10,min_length=1,required=True)



class ATKT11ScholarshipForm(forms.Form):
    s_name = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Scholarship Name"}),label="Scholarship Name",queryset=AddScholarship.objects.all(),required=True)
    year = forms.ModelChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "Select Year"}),label="Year",queryset=Year.objects.all(),required=True)
    faculty = forms.ChoiceField(widget=forms.Select(attrs={'class':"form-control select2bs4",'style':"width: 100%;",'title': "select Faculty"}),label="Faculty",choices=ADM_FACULTY,required=True)
    amount = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Amount Per Month",'type':"number",'placeholder': "Enter Amount Per Month",'onchange':"totalcal()"}),label="Amount Per Month",max_length=5,min_length=2,required=True)
    no_of_month = forms.CharField(widget=forms.TextInput(attrs={'title': "Enter Number of Month",'type':"number",'placeholder': "Enter Number of Month",'onchange':"totalcal()"}),label="Number of Month",max_length=2,min_length=1,required=True)
    total = forms.CharField(widget=forms.TextInput(attrs={'title': "Total",'type':"number",'placeholder': "Total",'readonly':"true"}),label="Total",max_length=10,min_length=1,required=True)
