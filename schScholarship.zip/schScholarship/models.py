from django.db import models
from schSetup.setupModels.setup_cast_models import CastCategory
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,Form1710Adm,Form1712Adm,ATKT11Adm


# Create your models here.



class AddScholarship(models.Model):
    s_name = models.CharField(max_length=200,unique=True)
    gender = models.CharField(max_length=20)
    apply_for = models.CharField(max_length=50,null=True)
    category = models.CharField(max_length=200,null=True)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    updated_at = models.DateTimeField(auto_now=True,null=True)
    class Meta:
        db_table:"scholarshipadd"
    def __str__(self):
        return self.s_name



class PrimaryScholarship(models.Model):
    s_name = models.ForeignKey(AddScholarship,on_delete=models.CASCADE)
    stud = models.ForeignKey(PrimAdm,on_delete=models.CASCADE)
    year = models.CharField(max_length=10)
    s_class = models.CharField(max_length=1)
    s_div = models.CharField(max_length=5,null=True)
    amount = models.CharField(max_length=5)
    no_of_month = models.CharField(max_length=2)
    total = models.CharField(max_length=10)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    class Meta:
        db_table:"scholarshipprimary"

    

class SecondaryScholarship(models.Model):
    s_name = models.ForeignKey(AddScholarship,on_delete=models.CASCADE)
    stud = models.ForeignKey(SecondAdm,on_delete=models.CASCADE)
    year = models.CharField(max_length=10)
    s_class = models.CharField(max_length=1)
    s_div = models.CharField(max_length=5,null=True)
    amount = models.CharField(max_length=5)
    no_of_month = models.CharField(max_length=2)
    total = models.CharField(max_length=10)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    class Meta:
        db_table:"scholarshipsecondary"



class CollegeScholarship(models.Model):
    s_name = models.ForeignKey(AddScholarship,on_delete=models.CASCADE)
    stud = models.ForeignKey(CollegeAdm,on_delete=models.CASCADE)
    year = models.CharField(max_length=10)
    s_class = models.CharField(max_length=2)
    faculty = models.CharField(max_length=20)
    s_div = models.CharField(max_length=5,null=True)
    amount = models.CharField(max_length=5)
    no_of_month = models.CharField(max_length=2)
    total = models.CharField(max_length=10)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    class Meta:
        db_table:"scholarshipcollege"



class ATKT11Scholarship(models.Model):
    s_name = models.ForeignKey(AddScholarship,on_delete=models.CASCADE)
    stud = models.ForeignKey(ATKT11Adm,on_delete=models.CASCADE)
    year = models.CharField(max_length=10)
    faculty = models.CharField(max_length=20)
    amount = models.CharField(max_length=5)
    no_of_month = models.CharField(max_length=2)
    total = models.CharField(max_length=10)
    submitted_at = models.DateTimeField(auto_now_add=True,null=True)
    class Meta:
        db_table:"scholarshipatkt11"


