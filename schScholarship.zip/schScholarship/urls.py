from django.urls import path,include
from schScholarship.scholarshipViews import addViews
from schScholarship.scholarshipViews import listViews
from schScholarship.scholarshipViews import deleteViews

urlpatterns = [
    # Scholarship main table
    path('scholarshipaddView',addViews.scholarship_addView,name='scholarship_addView'),
    path('scholarshipeditView/<int:sid>',addViews.scholarship_editView,name='scholarship_editView'),
    # scholarship add views 
    path('prischolarshipaddstudent',addViews.prischolarship_addstudent,name='prischolarship_addstudent'),
    path('secscholarshipaddstudent',addViews.secscholarship_addstudent,name='secscholarship_addstudent'),
    path('colscholarshipaddstudent',addViews.colscholarship_addstudent,name='colscholarship_addstudent'),
    path('atktscholarshipaddstudent',addViews.atktscholarship_addstudent,name='atktscholarship_addstudent'),
    # scholarship list views 
    path('prischolarshipliststudent',listViews.prischolarship_liststudent,name='prischolarship_liststudent'),
    path('secscholarshipliststudent',listViews.secscholarship_liststudent,name='secscholarship_liststudent'),
    path('colscholarshipliststudent',listViews.colscholarship_liststudent,name='colscholarship_liststudent'),
    path('atktscholarshipliststudent',listViews.atktscholarship_liststudent,name='atktscholarship_liststudent'),
    
    # delete views
    path('scholarshipdeleteView/<int:sid>',deleteViews.scholarship_deleteView,name='scholarship_deleteView'),
    path('prischolarshipdelView/<int:sid>',deleteViews.prischolarship_delView,name='prischolarship_delView'),
    path('secscholarshipdelView/<int:sid>',deleteViews.secscholarship_delView,name='secscholarship_delView'),
    path('colscholarshipdelView/<int:sid>',deleteViews.colscholarship_delView,name='colscholarship_delView'),
    path('atktscholarshipdelView/<int:sid>',deleteViews.atktscholarship_delView,name='atktscholarship_delView'),
]