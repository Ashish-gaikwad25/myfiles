from django.shortcuts import redirect,render
from schScholarship.forms import AddScholarshipForm,PriScholarshipForm,SecScholarshipForm,ColScholarshipForm,ATKT11ScholarshipForm
from schScholarship.models import AddScholarship,PrimaryScholarship,SecondaryScholarship,CollegeScholarship,ATKT11Scholarship
from django.contrib import messages
from django.conf import settings as conf_set
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm
from schSetup.setupModels.setup_cast_models import CastCategory,Cast
from schAdmission.admForms.admissionForms import GetAdmYearForm
import datetime

# Create your views here.
sname=conf_set.SCHOOL_NAME

# Primary scholarship List View
def prischolarship_liststudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    priSData = PrimaryScholarship.objects.filter(year=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Scholarship /",
                    'fname':fname,
                    "page_path":" Primary-Scholarship / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "priSData":priSData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/scholarship/primarylist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Primary Scholarship List form... Try again")
                    return redirect('prischolarship_liststudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            priSData=PrimaryScholarship.objects.filter(year=cy[0:4])
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":" Primary Scholarship / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "priSData":priSData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/scholarship/primarylist.html',context) 
    else:
        return redirect('login') 



# Secondary scholarship List View
def secscholarship_liststudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    secSData = SecondaryScholarship.objects.filter(year=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Scholarship /",
                    'fname':fname,
                    "page_path":" Secondary-Scholarship / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "secSData":secSData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/scholarship/secondarylist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Secondary Scholarship List form... Try again")
                    return redirect('secscholarship_liststudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate= GetAdmYearForm()
            secSData=SecondaryScholarship.objects.filter(year=cy[0:4])
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":"Secondary Scholarship / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "secSData":secSData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/scholarship/secondarylist.html',context) 
    else:
        return redirect('login') 


# Jr.College scholarship List View
def colscholarship_liststudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    colSData = CollegeScholarship.objects.filter(year=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Scholarship /",
                    'fname':fname,
                    "page_path":" Jr.College-Scholarship / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "colSData":colSData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/scholarship/collegelist.html',context) 
                except:
                    messages.error(request,"Invalid header found in Jr.College Scholarship List form... Try again")
                    return redirect('colscholarship_liststudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate = GetAdmYearForm()
            colSData = CollegeScholarship.objects.filter(year=cy[0:4])
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":"Jr.College Scholarship / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "colSData":colSData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/scholarship/collegelist.html',context) 
    else:
        return redirect('login') 


# 11-ATKT scholarship List View
def atktscholarship_liststudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            
            getAdmDate = GetAdmYearForm(request.POST)
            if getAdmDate.is_valid():
                try:
                    cy=str(getAdmDate.cleaned_data['year'])
                    print("Year=",cy)
                    atktSData = ATKT11Scholarship.objects.filter(year=cy[0:4])
                    context = {
                    'sname':sname,
                    'lname':lname,
                    'page_title':" Scholarship /",
                    'fname':fname,
                    "page_path":" 11-ATKT-Scholarship / Student List",
                    "menu_icon":"nav-icon fas fa-school",
                    "atktSData":atktSData,
                    "getAdmDate":getAdmDate,
                    "cy": cy[0:4]
                     }    
                    return render(request, 'schoolviews/scholarship/atkt11list.html',context) 
                except:
                    messages.error(request,"Invalid header found in 11-ATKT Scholarship List form... Try again")
                    return redirect('atktscholarship_liststudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            now = datetime.datetime.now()
            cy=str(now.year)
            print(cy)
            getAdmDate = GetAdmYearForm()
            atktSData = ATKT11Scholarship.objects.filter(year=cy[0:4])
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":"11-ATKT Scholarship / List Student",
            "menu_icon":"nav-icon fas fa-school",
            "atktSData":atktSData,
            "getAdmDate":getAdmDate,
            "cy" : cy
            }    
        return render(request, 'schoolviews/scholarship/atkt11list.html',context) 
    else:
        return redirect('login') 