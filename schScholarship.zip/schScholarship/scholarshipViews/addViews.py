from django.shortcuts import redirect,render
from schScholarship.forms import AddScholarshipForm,PriScholarshipForm,SecScholarshipForm,ColScholarshipForm,ATKT11ScholarshipForm
from schScholarship.models import AddScholarship,PrimaryScholarship,SecondaryScholarship,CollegeScholarship,ATKT11Scholarship
from django.contrib import messages
from django.conf import settings as conf_set
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm,ATKT11Adm
from django.db.models import Q
from schSetup.setupModels.setup_cast_models import CastCategory,Cast

# Create your views here.
sname=conf_set.SCHOOL_NAME




def scholarship_addView(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        scholarshipData = AddScholarship.objects.all()
        if request.method == 'POST':
            scholarshipForm= AddScholarshipForm(request.POST,request.FILES)
            if scholarshipForm.is_valid():
                try:
                    if AddScholarship.objects.filter(s_name__iexact=scholarshipForm.cleaned_data['s_name']).exists():
                        messages.error(request,"Scholarship Name Already Exists")
                        return redirect('scholarship_addView')
                    else:
                        scholarModule=AddScholarship()
                        scholarModule.s_name=scholarshipForm.cleaned_data['s_name']
                        scholarModule.gender=scholarshipForm.cleaned_data['gender']
                        scholarModule.apply_for=scholarshipForm.cleaned_data['apply_for']
                        scholarModule.category=scholarshipForm.cleaned_data['category']
                        scholarModule.save()
                        messages.success(request,"Scholarship Successfully Added")
                        return redirect('scholarship_addView')    
                except:
                    messages.error(request,"Invalid header found in  Scholarship Add form... Try again")
                    return redirect('scholarship_addView')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            scholarshipForm= AddScholarshipForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":"Add Scholarship",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            "scholarshipForm":scholarshipForm,
            "scholarshipData":scholarshipData,
            }    
        return render(request, 'schoolviews/scholarship/scholarship_add.html',context) 
    else:
        return redirect('login')




def scholarship_editView(request,sid):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        scholarshipData = AddScholarship.objects.all()
        if request.method == 'POST':
            pi=AddScholarship.objects.get(pk=sid)
            scholarshipForm = AddScholarshipForm(request.POST,request.FILES,instance=pi)
            if scholarshipForm.is_valid():
                try:
                    scholarshipForm.save()
                    messages.success(request,"Scholarship Successfully Edited")
                    return redirect('scholarship_addView')    
                except:
                    messages.error(request,"Invalid header found in  Scholarship Add form... Try again")
                    return redirect('scholarship_addView')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            pi=AddScholarship.objects.get(pk=sid)
            scholarshipForm = AddScholarshipForm(instance=pi)
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":"Edit Scholarship",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            "scholarshipForm":scholarshipForm,
            "scholarshipData":scholarshipData,
            }    
        return render(request, 'schoolviews/scholarship/scholarship_add.html',context) 
    else:
        return redirect('login')

def prischolarship_addstudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            prischolarForm= PriScholarshipForm(request.POST,request.FILES)
            if prischolarForm.is_valid():
                try:
                    amt=prischolarForm.cleaned_data['amount']
                    month=prischolarForm.cleaned_data['no_of_month']
                    total=prischolarForm.cleaned_data['total']
                    class_from=int(prischolarForm.cleaned_data['class_from'])
                    class_to=int(prischolarForm.cleaned_data['class_to'])
                    year=str(prischolarForm.cleaned_data['year'])
                    scholarshipData = AddScholarship.objects.get(s_name=prischolarForm.cleaned_data['s_name'])
                    gender=scholarshipData.gender
                    gender=gender.replace('[',"")
                    gender=gender.replace(']',"")
                    gender=gender.replace("'","")
                    gender=gender.split(', ')
                    print(gender)
                    apply=scholarshipData.apply_for
                    apply=apply.replace('[',"")
                    apply=apply.replace(']',"")
                    apply=apply.replace("'","")
                    apply=apply.split(', ')
                    print(apply)
                    cat=scholarshipData.category
                    cat=cat.replace('[',"")
                    cat=cat.replace(']',"")
                    cat=cat.replace("'","")
                    cat=cat.split(', ')
                    print(cat)
                    catData=CastCategory.objects.filter(castCategoryName__in=cat)
                    print(catData)
                    casteData = Cast.objects.filter(castCat__in=catData)
                    print(casteData)
                    if class_from <= class_to:
                        for i in range(class_from,class_to+1):
                            if apply!=[''] and cat!=['']:
                                print(1)
                                if 'bpl' in apply:
                                    if i==1:
                                        priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,bpl="YES",updateyear1=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision1
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==2:
                                        priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,bpl="YES",updateyear2=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision2
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==3:
                                        priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,bpl="YES",updateyear3=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision3
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==4:
                                        priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,bpl="YES",updateyear4=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision4
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                if 'minority' in apply:
                                    if i==1:
                                        priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,minority="YES",updateyear1=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision1
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==2:
                                        priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,minority="YES",updateyear2=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision2
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==3:
                                        priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,minority="YES",updateyear3=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision3
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==4:
                                        priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,minority="YES",updateyear4=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision4
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                if 'pwd' in apply:
                                    if i==1:
                                        priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,pwd="YES",updateyear1=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision1
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==2:
                                        priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,pwd="YES",updateyear2=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision2
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==3:
                                        priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,pwd="YES",updateyear3=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision3
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==4:
                                        priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,pwd="YES",updateyear4=year[0:4],cast__in=casteData)
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision4
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                            elif apply!=[''] and cat==['']:
                                print(2)
                                if 'bpl' in apply:
                                    if i==1:
                                        priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,bpl="YES",updateyear1=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision1
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==2:
                                        priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,bpl="YES",updateyear2=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision2
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==3:
                                        priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,bpl="YES",updateyear3=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision3
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==4:
                                        priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,bpl="YES",updateyear4=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision4
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                if 'minority' in apply:
                                    if i==1:
                                        priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,minority="YES",updateyear1=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision1
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==2:
                                        priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,minority="YES",updateyear2=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision2
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==3:
                                        priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,minority="YES",updateyear3=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision3
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==4:
                                        priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,minority="YES",updateyear4=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision4
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                if 'pwd' in apply:
                                    if i==1:
                                        priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,pwd="YES",updateyear1=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision1
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==2:
                                        priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,pwd="YES",updateyear2=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision2
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==3:
                                        priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,pwd="YES",updateyear3=year[0:4])
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision3
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                                    elif i==4:
                                        priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,pwd="YES",updateyear4=year[0:4])                            
                                        for pri in priData:
                                            if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                priModule=PrimaryScholarship()
                                                priModule.s_name=scholarshipData
                                                priModule.stud=pri
                                                priModule.year=year[0:4]
                                                priModule.s_class=i
                                                priModule.s_div=pri.updatedivision4
                                                priModule.amount=amt
                                                priModule.no_of_month=month
                                                priModule.total=total
                                                priModule.save()
                            elif apply==[''] and cat!=['']:
                                print(3)
                                if i==1:
                                    priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,updateyear1=year[0:4],cast__in=casteData)
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision1
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                                elif i==2:
                                    priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,updateyear2=year[0:4],cast__in=casteData)
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision2
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                                elif i==3:
                                    priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,updateyear3=year[0:4],cast__in=casteData)
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision3
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                                elif i==4:
                                    priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,updateyear4=year[0:4],cast__in=casteData)
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision4
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                            elif apply==[''] and cat==['']:
                                print(4)
                                if i==1:
                                    priData = PrimAdm.objects.filter(updateclass1="1",sex__in=gender,updateyear1=year[0:4])
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision1
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                                elif i==2:
                                    priData = PrimAdm.objects.filter(updateclass2="2",sex__in=gender,updateyear2=year[0:4])
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision2
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                                elif i==3:
                                    priData = PrimAdm.objects.filter(updateclass3="3",sex__in=gender,updateyear3=year[0:4])
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision3
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                                elif i==4:
                                    priData = PrimAdm.objects.filter(updateclass4="4",sex__in=gender,updateyear4=year[0:4])
                                    for pri in priData:
                                        if PrimaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            priModule=PrimaryScholarship()
                                            priModule.s_name=scholarshipData
                                            priModule.stud=pri
                                            priModule.year=year[0:4]
                                            priModule.s_class=i
                                            priModule.s_div=pri.updatedivision4
                                            priModule.amount=amt
                                            priModule.no_of_month=month
                                            priModule.total=total
                                            priModule.save()
                    else:
                        messages.error(request,"Standard from and to are not valid")
                        return redirect('prischolarship_addstudent') 
                    messages.success(request,"Scholarship Successfully Added")
                    return redirect('prischolarship_addstudent')    
                except:
                    messages.error(request,"Invalid header found in  Scholarship Add form... Try again")
                    return redirect('prischolarship_addstudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            prischolarForm= PriScholarshipForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":" Primary Scholarship",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            "prischolarForm":prischolarForm,
            }    
        return render(request, 'schoolviews/scholarship/prischolarship.html',context) 
    else:
        return redirect('login')



def secscholarship_addstudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            secscholarForm= SecScholarshipForm(request.POST,request.FILES)
            if secscholarForm.is_valid():
                try:
                    amt=secscholarForm.cleaned_data['amount']
                    month=secscholarForm.cleaned_data['no_of_month']
                    total=secscholarForm.cleaned_data['total']
                    class_from=int(secscholarForm.cleaned_data['class_from'])
                    class_to=int(secscholarForm.cleaned_data['class_to'])
                    year=str(secscholarForm.cleaned_data['year'])
                    scholarshipData = AddScholarship.objects.get(s_name=secscholarForm.cleaned_data['s_name'])
                    gender=scholarshipData.gender
                    gender=gender.replace('[',"")
                    gender=gender.replace(']',"")
                    gender=gender.replace("'","")
                    gender=gender.split(', ')
                    print(gender)
                    apply=scholarshipData.apply_for
                    apply=apply.replace('[',"")
                    apply=apply.replace(']',"")
                    apply=apply.replace("'","")
                    apply=apply.split(', ')
                    print(apply)
                    cat=scholarshipData.category
                    cat=cat.replace('[',"")
                    cat=cat.replace(']',"")
                    cat=cat.replace("'","")
                    cat=cat.split(', ')
                    print(cat)
                    catData=CastCategory.objects.filter(castCategoryName__in=cat)
                    print(catData)
                    casteData = Cast.objects.filter(castCat__in=catData)
                    print(casteData)
                    if class_from <= class_to:
                        for i in range(class_from,class_to+1):
                            if apply!=[''] and cat!=['']:
                                print(1)
                                if 'bpl' in apply:
                                    if i==5:
                                        secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,bpl="YES",updateyear5=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision5
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==6:
                                        secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,bpl="YES",updateyear6=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision6
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==7:
                                        secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,bpl="YES",updateyear7=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision7
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==8:
                                        secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,bpl="YES",updateyear8=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision8
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==9:
                                        secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,bpl="YES",updateyear9=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision9
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==10:
                                        secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,bpl="YES",updateyear10=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision10
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                if 'minority' in apply:
                                    if i==5:
                                        secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,minority="YES",updateyear5=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision5
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==6:
                                        secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,minority="YES",updateyear6=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision6
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==7:
                                        secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,minority="YES",updateyear7=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision7
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==8:
                                        secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,minority="YES",updateyear8=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision8
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==9:
                                        secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,minority="YES",updateyear9=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision9
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==10:
                                        secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,minority="YES",updateyear10=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision10
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                if 'pwd' in apply:
                                    if i==5:
                                        secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,pwd="YES",updateyear5=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision5
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==6:
                                        secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,pwd="YES",updateyear6=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision6
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==7:
                                        secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,pwd="YES",updateyear7=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision7
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==8:
                                        secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,pwd="YES",updateyear8=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision8
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==9:
                                        secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,pwd="YES",updateyear9=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision9
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==10:
                                        secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,pwd="YES",updateyear10=year[0:4],cast__in=casteData)
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision10
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                            elif apply!=[''] and cat==['']:
                                print(2)
                                if 'bpl' in apply:
                                    if i==5:
                                        secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,bpl="YES",updateyear5=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision5
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==6:
                                        secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,bpl="YES",updateyear6=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision6
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==7:
                                        secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,bpl="YES",updateyear7=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision7
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==8:
                                        secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,bpl="YES",updateyear8=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision8
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==9:
                                        secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,bpl="YES",updateyear9=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision9
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==10:
                                        secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,bpl="YES",updateyear10=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision10
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                if 'minority' in apply:
                                    if i==5:
                                        secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,minority="YES",updateyear5=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision5
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==6:
                                        secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,minority="YES",updateyear6=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision6
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==7:
                                        secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,minority="YES",updateyear7=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision7
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==8:
                                        secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,minority="YES",updateyear8=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision8
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==9:
                                        secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,minority="YES",updateyear9=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision9
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==10:
                                        secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,minority="YES",updateyear10=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision10
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                if 'pwd' in apply:
                                    if i==5:
                                        secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,pwd="YES",updateyear5=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision5
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==6:
                                        secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,pwd="YES",updateyear6=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision6
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==7:
                                        secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,pwd="YES",updateyear7=year[0:4])
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision7
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==8:
                                        secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,pwd="YES",updateyear8=year[0:4])                            
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision8
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==9:
                                        secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,pwd="YES",updateyear9=year[0:4])                            
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision9
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                                    elif i==10:
                                        secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,pwd="YES",updateyear10=year[0:4])                            
                                        for pri in secData:
                                            if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                secModule=SecondaryScholarship()
                                                secModule.s_name=scholarshipData
                                                secModule.stud=pri
                                                secModule.year=year[0:4]
                                                secModule.s_class=i
                                                secModule.s_div=pri.updatedivision10
                                                secModule.amount=amt
                                                secModule.no_of_month=month
                                                secModule.total=total
                                                secModule.save()
                            elif apply==[''] and cat!=['']:
                                print(3)
                                if i==5:
                                    secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,updateyear5=year[0:4],cast__in=casteData)
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision5
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==6:
                                    secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,updateyear6=year[0:4],cast__in=casteData)
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision6
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==7:
                                    secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,updateyear7=year[0:4],cast__in=casteData)
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision7
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==8:
                                    secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,updateyear8=year[0:4],cast__in=casteData)
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision8
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==9:
                                    secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,updateyear9=year[0:4],cast__in=casteData)
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision9
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==10:
                                    secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,updateyear10=year[0:4],cast__in=casteData)
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision10
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                            elif apply==[''] and cat==['']:
                                print(4)
                                if i==5:
                                    secData = SecondAdm.objects.filter(updateclass5="5",sex__in=gender,updateyear5=year[0:4])
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision5
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==6:
                                    secData = SecondAdm.objects.filter(updateclass6="6",sex__in=gender,updateyear6=year[0:4])
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision6
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==7:
                                    secData = SecondAdm.objects.filter(updateclass7="7",sex__in=gender,updateyear7=year[0:4])
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision7
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==8:
                                    secData = SecondAdm.objects.filter(updateclass8="8",sex__in=gender,updateyear8=year[0:4])
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision8
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==9:
                                    secData = SecondAdm.objects.filter(updateclass9="9",sex__in=gender,updateyear9=year[0:4])
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision9
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                                elif i==10:
                                    secData = SecondAdm.objects.filter(updateclass10="10",sex__in=gender,updateyear10=year[0:4])
                                    for pri in secData:
                                        if SecondaryScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            secModule=SecondaryScholarship()
                                            secModule.s_name=scholarshipData
                                            secModule.stud=pri
                                            secModule.year=year[0:4]
                                            secModule.s_class=i
                                            secModule.s_div=pri.updatedivision10
                                            secModule.amount=amt
                                            secModule.no_of_month=month
                                            secModule.total=total
                                            secModule.save()
                    else:
                        messages.error(request,"Standard from and to are not valid")
                        return redirect('secscholarship_addstudent')
                    messages.success(request,"Scholarship Successfully Added")
                    return redirect('secscholarship_addstudent')    
                except:
                    messages.error(request,"Invalid header found in  Scholarship Add form... Try again")
                    return redirect('secscholarship_addstudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            secscholarForm= SecScholarshipForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":" Secondary Scholarship",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            "secscholarForm":secscholarForm,
            }    
        return render(request, 'schoolviews/scholarship/secscholarship.html',context) 
    else:
        return redirect('login')



def colscholarship_addstudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            colscholarForm= ColScholarshipForm(request.POST,request.FILES)
            if colscholarForm.is_valid():
                try:
                    amt=colscholarForm.cleaned_data['amount']
                    month=colscholarForm.cleaned_data['no_of_month']
                    total=colscholarForm.cleaned_data['total']
                    class_from=int(colscholarForm.cleaned_data['class_from'])
                    class_to=int(colscholarForm.cleaned_data['class_to'])
                    year=str(colscholarForm.cleaned_data['year'])
                    faculty=str(colscholarForm.cleaned_data['faculty'])
                    scholarshipData = AddScholarship.objects.get(s_name=colscholarForm.cleaned_data['s_name'])
                    gender=scholarshipData.gender
                    gender=gender.replace('[',"")
                    gender=gender.replace(']',"")
                    gender=gender.replace("'","")
                    gender=gender.split(', ')
                    print(gender)
                    apply=scholarshipData.apply_for
                    apply=apply.replace('[',"")
                    apply=apply.replace(']',"")
                    apply=apply.replace("'","")
                    apply=apply.split(', ')
                    print(apply)
                    cat=scholarshipData.category
                    cat=cat.replace('[',"")
                    cat=cat.replace(']',"")
                    cat=cat.replace("'","")
                    cat=cat.split(', ')
                    print(cat)
                    catData=CastCategory.objects.filter(castCategoryName__in=cat)
                    print(catData)
                    casteData = Cast.objects.filter(castCat__in=catData)
                    print(casteData)
                    if class_from <= class_to:
                        for i in range(class_from,class_to+1):
                            if apply!=[''] and cat!=['']:
                                print(1)
                                if 'bpl' in apply:
                                    if i==11:
                                        colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,bpl="YES",updateyear11=year[0:4],cast__in=casteData)
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream11
                                                colModule.s_div=pri.updatedivision11
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                    elif i==12:
                                        colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,bpl="YES",updateyear12=year[0:4],cast__in=casteData)
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream12
                                                colModule.s_div=pri.updatedivision12
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                if 'minority' in apply:
                                    if i==11:
                                        colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,minority="YES",updateyear11=year[0:4],cast__in=casteData)
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream11
                                                colModule.s_div=pri.updatedivision11
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                    elif i==12:
                                        colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,minority="YES",updateyear12=year[0:4],cast__in=casteData)
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream12
                                                colModule.s_div=pri.updatedivision12
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                if 'pwd' in apply:
                                    if i==11:
                                        colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,pwd="YES",updateyear11=year[0:4],cast__in=casteData)
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream11
                                                colModule.s_div=pri.updatedivision11
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                    elif i==12:
                                        colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,pwd="YES",updateyear12=year[0:4],cast__in=casteData)
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream12
                                                colModule.s_div=pri.updatedivision12
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                            elif apply!=[''] and cat==['']:
                                print(2)
                                if 'bpl' in apply:
                                    if i==11:
                                        colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,bpl="YES",updateyear11=year[0:4])
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream11
                                                colModule.s_div=pri.updatedivision11
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                    elif i==12:
                                        colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,bpl="YES",updateyear12=year[0:4])
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream12
                                                colModule.s_div=pri.updatedivision12
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                if 'minority' in apply:
                                    if i==11:
                                        colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,minority="YES",updateyear11=year[0:4])
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream11
                                                colModule.s_div=pri.updatedivision11
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                    elif i==12:
                                        colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,minority="YES",updateyear12=year[0:4])
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream12
                                                colModule.s_div=pri.updatedivision12
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                if 'pwd' in apply:
                                    if i==11:
                                        colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,pwd="YES",updateyear11=year[0:4])
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream11
                                                colModule.s_div=pri.updatedivision11
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                                    elif i==12:
                                        colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,pwd="YES",updateyear12=year[0:4])
                                        for pri in colData:
                                            if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                                print("exists")
                                            else:
                                                colModule=CollegeScholarship()
                                                colModule.s_name=scholarshipData
                                                colModule.stud=pri
                                                colModule.year=year[0:4]
                                                colModule.s_class=i
                                                colModule.faculty=pri.updatestream12
                                                colModule.s_div=pri.updatedivision12
                                                colModule.amount=amt
                                                colModule.no_of_month=month
                                                colModule.total=total
                                                colModule.save()
                            elif apply==[''] and cat!=['']:
                                print(3)
                                if i==11:
                                    colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,updateyear11=year[0:4],cast__in=casteData)
                                    for pri in colData:
                                        if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            colModule=CollegeScholarship()
                                            colModule.s_name=scholarshipData
                                            colModule.stud=pri
                                            colModule.year=year[0:4]
                                            colModule.s_class=i
                                            colModule.faculty=pri.updatestream11
                                            colModule.s_div=pri.updatedivision11
                                            colModule.amount=amt
                                            colModule.no_of_month=month
                                            colModule.total=total
                                            colModule.save()
                                elif i==12:
                                    colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,updateyear12=year[0:4],cast__in=casteData)
                                    for pri in colData:
                                        if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            colModule=CollegeScholarship()
                                            colModule.s_name=scholarshipData
                                            colModule.stud=pri
                                            colModule.year=year[0:4]
                                            colModule.s_class=i
                                            colModule.faculty=pri.updatestream12
                                            colModule.s_div=pri.updatedivision12
                                            colModule.amount=amt
                                            colModule.no_of_month=month
                                            colModule.total=total
                                            colModule.save()
                                            print(123)
                            elif apply==[''] and cat==['']:
                                print(4)
                                if i==11:
                                    colData = CollegeAdm.objects.filter(updateclass11="11",updatestream11=faculty,sex__in=gender,updateyear11=year[0:4])
                                    for pri in colData:
                                        if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            colModule=CollegeScholarship()
                                            colModule.s_name=scholarshipData
                                            colModule.stud=pri
                                            colModule.year=year[0:4]
                                            colModule.s_class=i
                                            colModule.faculty=pri.updatestream11
                                            colModule.s_div=pri.updatedivision11
                                            colModule.amount=amt
                                            colModule.no_of_month=month
                                            colModule.total=total
                                            colModule.save()
                                elif i==12:
                                    colData = CollegeAdm.objects.filter(updateclass12="12",updatestream12=faculty,sex__in=gender,updateyear12=year[0:4])
                                    for pri in colData:
                                        if CollegeScholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                            print("exists")
                                        else:
                                            colModule=CollegeScholarship()
                                            colModule.s_name=scholarshipData
                                            colModule.stud=pri
                                            colModule.year=year[0:4]
                                            colModule.s_class=i
                                            colModule.faculty=pri.updatestream12
                                            colModule.s_div=pri.updatedivision12
                                            colModule.amount=amt
                                            colModule.no_of_month=month
                                            colModule.total=total
                                            colModule.save()
                    else:
                        messages.error(request,"Standard from and to are not valid")
                        return redirect('colscholarship_addstudent') 
                    messages.success(request,"Scholarship Successfully Added")
                    return redirect('colscholarship_addstudent')    
                except:
                    messages.error(request,"Invalid header found in  Scholarship Add form... Try again")
                    return redirect('colscholarship_addstudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            colscholarForm= ColScholarshipForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":" Jr.College Scholarship",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            "colscholarForm":colscholarForm,
            }    
        return render(request, 'schoolviews/scholarship/colscholarship.html',context) 
    else:
        return redirect('login')


def atktscholarship_addstudent(request):
    if request.session.has_key('username'):
        lname=request.user.last_name 
        fname=request.user.first_name
        if request.method == 'POST':
            atktscholarForm= ATKT11ScholarshipForm(request.POST,request.FILES)
            if atktscholarForm.is_valid():
                try:
                    amt=atktscholarForm.cleaned_data['amount']
                    month=atktscholarForm.cleaned_data['no_of_month']
                    total=atktscholarForm.cleaned_data['total']
                    year=str(atktscholarForm.cleaned_data['year'])
                    faculty=str(atktscholarForm.cleaned_data['faculty'])
                    scholarshipData = AddScholarship.objects.get(s_name=atktscholarForm.cleaned_data['s_name'])
                    gender=scholarshipData.gender
                    gender=gender.replace('[',"")
                    gender=gender.replace(']',"")
                    gender=gender.replace("'","")
                    gender=gender.split(', ')
                    print(gender)
                    apply=scholarshipData.apply_for
                    apply=apply.replace('[',"")
                    apply=apply.replace(']',"")
                    apply=apply.replace("'","")
                    apply=apply.split(', ')
                    print(apply)
                    cat=scholarshipData.category
                    cat=cat.replace('[',"")
                    cat=cat.replace(']',"")
                    cat=cat.replace("'","")
                    cat=cat.split(', ')
                    print(cat)
                    catData=CastCategory.objects.filter(castCategoryName__in=cat)
                    print(catData)
                    casteData = Cast.objects.filter(castCat__in=catData)
                    print(casteData)
                    if apply!=[''] and cat!=['']:
                        print(1)
                        if 'bpl' in apply:
                            atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,bpl="YES",admyear=year[0:4],cast__in=casteData)
                            for pri in atktData:
                                if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                    print("exists")
                                else:
                                    atktModule=ATKT11Scholarship()
                                    atktModule.s_name=scholarshipData
                                    atktModule.stud=pri
                                    atktModule.year=year[0:4]
                                    atktModule.faculty=pri.admission_faculty
                                    atktModule.amount=amt
                                    atktModule.no_of_month=month
                                    atktModule.total=total
                                    atktModule.save()
                        if 'minority' in apply:
                            atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,minority="YES",admyear=year[0:4],cast__in=casteData)
                            for pri in atktData:
                                if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                    print("exists")
                                else:
                                    atktModule=ATKT11Scholarship()
                                    atktModule.s_name=scholarshipData
                                    atktModule.stud=pri
                                    atktModule.year=year[0:4]
                                    atktModule.faculty=pri.admission_faculty
                                    atktModule.amount=amt
                                    atktModule.no_of_month=month
                                    atktModule.total=total
                                    atktModule.save()
                        if 'pwd' in apply:
                            atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,pwd="YES",admyear=year[0:4],cast__in=casteData)
                            for pri in atktData:
                                if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                    print("exists")
                                else:
                                    atktModule=ATKT11Scholarship()
                                    atktModule.s_name=scholarshipData
                                    atktModule.stud=pri
                                    atktModule.year=year[0:4]
                                    atktModule.faculty=pri.admission_faculty
                                    atktModule.amount=amt
                                    atktModule.no_of_month=month
                                    atktModule.total=total
                                    atktModule.save()
                    elif apply!=[''] and cat==['']:
                        print(2)
                        if 'bpl' in apply:
                            atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,bpl="YES",admyear=year[0:4])
                            for pri in atktData:
                                if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                    print("exists")
                                else:
                                    atktModule=ATKT11Scholarship()
                                    atktModule.s_name=scholarshipData
                                    atktModule.stud=pri
                                    atktModule.year=year[0:4]
                                    atktModule.faculty=pri.admission_faculty
                                    atktModule.amount=amt
                                    atktModule.no_of_month=month
                                    atktModule.total=total
                                    atktModule.save()
                        if 'minority' in apply:
                            atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,minority="YES",admyear=year[0:4])
                            for pri in atktData:
                                if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                    print("exists")
                                else:
                                    atktModule=ATKT11Scholarship()
                                    atktModule.s_name=scholarshipData
                                    atktModule.stud=pri
                                    atktModule.year=year[0:4]
                                    atktModule.faculty=pri.admission_faculty
                                    atktModule.amount=amt
                                    atktModule.no_of_month=month
                                    atktModule.total=total
                                    atktModule.save()
                        if 'pwd' in apply:
                            atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,pwd="YES",admyear=year[0:4])
                            for pri in atktData:
                                if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                    print("exists")
                                else:
                                    atktModule=ATKT11Scholarship()
                                    atktModule.s_name=scholarshipData
                                    atktModule.stud=pri
                                    atktModule.year=year[0:4]
                                    atktModule.faculty=pri.admission_faculty
                                    atktModule.amount=amt
                                    atktModule.no_of_month=month
                                    atktModule.total=total
                                    atktModule.save()
                    elif apply==[''] and cat!=['']:
                        print(3)
                        atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,admyear=year[0:4],cast__in=casteData)
                        for pri in atktData:
                            if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                print("exists")
                            else:
                                print(3)
                                atktModule=ATKT11Scholarship()
                                atktModule.s_name=scholarshipData
                                atktModule.stud=pri
                                atktModule.year=year[0:4]
                                atktModule.faculty=pri.admission_faculty
                                atktModule.amount=amt
                                atktModule.no_of_month=month
                                atktModule.total=total
                                atktModule.save()
                    elif apply==[''] and cat==['']:
                        print(4)
                        atktData = ATKT11Adm.objects.filter(admission_faculty=faculty,sex__in=gender,admyear=year[0:4])
                        for pri in atktData:
                            if ATKT11Scholarship.objects.filter(s_name=scholarshipData,stud=pri,year=year[0:4]).exists():
                                print("exists")
                            else:
                                atktModule=ATKT11Scholarship()
                                atktModule.s_name=scholarshipData
                                atktModule.stud=pri
                                atktModule.year=year[0:4]
                                atktModule.faculty=pri.admission_faculty
                                atktModule.amount=amt
                                atktModule.no_of_month=month
                                atktModule.total=total
                                atktModule.save()
                    messages.success(request,"Scholarship Successfully Added")
                    return redirect('atktscholarship_addstudent')    
                except:
                    messages.error(request,"Invalid header found in  Scholarship Add form... Try again")
                    return redirect('atktscholarship_addstudent')    
            else:
                messages.error(request, 'Please correct the error below.')
        else:
            atktscholarForm= ATKT11ScholarshipForm()
        context = {
            'sname':sname,
            'lname':lname,
            'page_title':" Scholarship /",
            'fname':fname,
            "page_path":" 11-ATKT Scholarship",
            "menu_icon":"nav-icon fa fa-graduation-cap",
            "atktscholarForm":atktscholarForm,
            }    
        return render(request, 'schoolviews/scholarship/atkt11scholarship.html',context) 
    else:
        return redirect('login')

                