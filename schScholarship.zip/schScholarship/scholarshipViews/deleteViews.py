from django.shortcuts import redirect,render
from schScholarship.forms import AddScholarshipForm,PriScholarshipForm,SecScholarshipForm,ColScholarshipForm,ATKT11ScholarshipForm
from schScholarship.models import AddScholarship,PrimaryScholarship,SecondaryScholarship,CollegeScholarship,ATKT11Scholarship
from django.contrib import messages
from django.conf import settings as conf_set
from schAdmission.admModels.admissionModels import PrimAdm,SecondAdm,CollegeAdm
from django.db.models import Q
from schSetup.setupModels.setup_cast_models import CastCategory,Cast


# Create your views here.
sname=conf_set.SCHOOL_NAME


# Scholarship Delete View
def scholarship_deleteView(request,sid):
    if request.method == 'POST':
        pi=AddScholarship.objects.get(pk=sid)
        pi.delete()
        messages.success(request, 'Scholarship Deleted Successfully!')
        return redirect('scholarship_addView')


# Primary Scholarship student Delete View
def prischolarship_delView(request,sid):
    if request.method == 'POST':
        pi=PrimaryScholarship.objects.get(pk=sid)
        pi.delete()
        messages.success(request, 'Scholarship Deleted Successfully!')
        return redirect('prischolarship_liststudent')


# Secondary Scholarship student Delete View
def secscholarship_delView(request,sid):
    if request.method == 'POST':
        pi=SecondaryScholarship.objects.get(pk=sid)
        pi.delete()
        messages.success(request, 'Scholarship Deleted Successfully!')
        return redirect('secscholarship_liststudent')


# Jr.College Scholarship student Delete View
def colscholarship_delView(request,sid):
    if request.method == 'POST':
        pi=CollegeScholarship.objects.get(pk=sid)
        pi.delete()
        messages.success(request, 'Scholarship Deleted Successfully!')
        return redirect('colscholarship_liststudent')


# 11-ATKT Scholarship student Delete View
def atktscholarship_delView(request,sid):
    if request.method == 'POST':
        pi=ATKT11Scholarship.objects.get(pk=sid)
        pi.delete()
        messages.success(request, 'Scholarship Deleted Successfully!')
        return redirect('atktscholarship_liststudent')