from django.apps import AppConfig


class SchscholarshipConfig(AppConfig):
    name = 'schScholarship'
